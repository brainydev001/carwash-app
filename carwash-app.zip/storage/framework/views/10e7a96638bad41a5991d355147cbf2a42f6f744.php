

<?php $__env->startSection('page'); ?>

<?php echo $__env->make('expenses.inc.expense-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',[
'title' => 'All expenses',
'breadcrumbs' => [
'Expenses manager' => url('expenses/manager')
]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/expenses/expenses.blade.php ENDPATH**/ ?>