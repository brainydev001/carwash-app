

<?php $__env->startSection('admincss'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>


<div class="container-fluid">
    
    <button class="btn btn-sm btn-primary mr-2" data-toggle="modal" data-target="#craeteServiceModal">
        Action btn
    </button>
</div>


<?php echo $__env->make('services.inc.services-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('services.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminjs'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'All Services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/services/services.blade.php ENDPATH**/ ?>