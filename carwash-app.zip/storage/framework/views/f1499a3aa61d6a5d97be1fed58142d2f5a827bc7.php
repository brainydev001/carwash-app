
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-body">
                            <?php if(count($staffs) > 0): ?>
                                <!-- table -->
                                <table class="table datatables" id="staffDataTable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone Number</th>
                                            <th>Created</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key + 1); ?></td>
                                                <td>
                                                    <div>
                                                        <?php echo e($staff->name); ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <a href="#">
                                                        <?php echo e($staff->email); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="#">
                                                        <?php echo e($staff->phonenumber); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <div>
                                                        <?php echo e(date('M-j-Y H:i', strtotime($staff->created_at))); ?>

                                                    </div>
                                                    <div>
                                                        <?php echo e($staff->created_at->diffForHumans()); ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm dropdown-toggle more-horizontal"
                                                        type="button" data-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <span class="text-muted sr-only">Action</span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item"
                                                            href="#">View</a>
                                                        <a class="dropdown-item" href="#">Remove</a>
                                                        <a class="dropdown-item" href="#">Assign</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    No users to show
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div> <!-- simple table -->
            </div> <!-- end section -->
        </div> <!-- .col-12 -->
    </div> <!-- .row -->
</div>
<?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/staff/inc/staff-table.blade.php ENDPATH**/ ?>