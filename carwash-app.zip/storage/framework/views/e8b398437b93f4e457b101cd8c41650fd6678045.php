

<?php $__env->startSection('page'); ?>


<div class="container-fluid">
     
     <a href="<?php echo e(url('all-services')); ?>" class="btn btn-sm btn-primary mr-2">
        All Services
    </a>
    
    <button class="btn btn-sm btn-primary mr-2" data-toggle="modal" data-target="#craeteBodyTypeModal">
        Create body type
    </button>
    
    <button class="btn btn-sm btn-primary mr-2" data-toggle="modal" data-target="#craeteServiceModal">
        Create service
    </button>  
</div>


<?php echo $__env->make('services.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'Services'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/services/index.blade.php ENDPATH**/ ?>