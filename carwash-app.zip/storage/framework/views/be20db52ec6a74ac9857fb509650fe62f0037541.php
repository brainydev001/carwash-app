

<?php $__env->startSection('page'); ?>

<div class="container-fluid">
    <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
        <div class="btn-group mr-2" role="group" aria-label="First group">
            <a href="<?php echo e(url('users')); ?>" class="btn mb-2 btn-secondary" title="View all users">
                <i class="fe fe-users fe-16"></i>
                <span class="pl-1">All users</span>
            </a>
            <button type="button" class="btn mb-2 btn-secondary">2</button>
            <button type="button" class="btn mb-2 btn-secondary">3</button>
            <button type="button" class="btn mb-2 btn-secondary">4</button>
        </div>
        <div class="btn-group" role="group" aria-label="Third group">
            <a href="<?php echo e(url('user/create')); ?>" class="btn mb-2 btn-success" title="Create new user">
                <i class="fe fe-user-plus fe-16"></i>
                <span class="pl-1">New</span>
            </a>
        </div>
    </div>
</div>


<div class="row mt-3 mb-3 container-fluid">
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('metrics.overview',[
        'name' => 'Total users',
        'icon' => 'fe-users',
        'total' => 0,
        'percentage' => 10
    ])->html();
} elseif ($_instance->childHasBeenRendered('fARi3rJ')) {
    $componentId = $_instance->getRenderedChildComponentId('fARi3rJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('fARi3rJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fARi3rJ');
} else {
    $response = \Livewire\Livewire::mount('metrics.overview',[
        'name' => 'Total users',
        'icon' => 'fe-users',
        'total' => 0,
        'percentage' => 10
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('fARi3rJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'Users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/users/index.blade.php ENDPATH**/ ?>