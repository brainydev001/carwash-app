
<?php if(session()->has('info-message')): ?>
<div class="alert alert-primary alert-dismissible fade show" role="alert">
    <span class="fe fe-info fe-16 mr-2"></span>
    <?php echo e(session()->get('info-message')); ?> 
    <button type="button"
        class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>    
<?php endif; ?>


<?php if(session()->has('success-message')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <span class="fe fe-check-circle fe-16 mr-2"></span>
    <?php echo e(session()->get('success-message')); ?> 
    <button type="button"
        class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>    
<?php endif; ?>


<?php if(session()->has('danger-message')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <span class="fe fe-alert-triangle fe-16 mr-2"></span>
    <?php echo e(session()->get('danger-message')); ?> 
    <button type="button"
        class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>    
<?php endif; ?>


<?php if(session()->has('warning-message')): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <span class="fe fe-alert-circle fe-16 mr-2"></span>
    <?php echo e(session()->get('warning-message')); ?> 
    <button type="button"
        class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>    
<?php endif; ?>


<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <span class="fe fe-alert-triangle fe-16 mr-2"></span>
        <?php echo e($error); ?> 
        <button type="button"
            class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/messages/alerts.blade.php ENDPATH**/ ?>