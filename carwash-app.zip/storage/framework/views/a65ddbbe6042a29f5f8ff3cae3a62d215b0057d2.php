<div class="row">
    <div class="form-group col-md-6">
        <label for="exampleInputEmail1">Plate number</label>
        <input type="text" name="plate_number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            placeholder="Plate number">
        <?php $__errorArgs = ['plate_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>

    <div class="form-group col-md-6">
        <label for="exampleInputEmail1">Full Name</label>
        <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            placeholder="Full Name">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-6">
        <label for="exampleInputEmail1">Phone number</label>
        <input type="text" name="phone_number" class="form-control" id="exampleInputEmail1"
            aria-describedby="emailHelp" placeholder="Phone number">
        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-6">
        <label for="exampleInputEmail1">Email</label>
        <input type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            placeholder="email">
        <small id="emailHelp" class="form-text text-primary">
            optional
        </small>
    </div>

    <div class="form-group col-md-6">
        <label for="exampleInputEmail1">Car make</label>
        <input type="text" name="make" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            placeholder="Car make">
        <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-6">
        <label for="exampleInputEmail1">Car model</label>
        <input type="text" name="model" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            placeholder="Car model">
        <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-12">
        <label for="exampleInputEmail1">Special notes</label>
        <textarea name="notes" class="form-control" rows="3"></textarea>
        <small id="emailHelp" class="form-text text-primary">
            optional
        </small>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/livewire/sale-terminal/checkout-form.blade.php ENDPATH**/ ?>