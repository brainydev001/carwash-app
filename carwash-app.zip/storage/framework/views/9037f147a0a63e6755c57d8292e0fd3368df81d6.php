<div class="text-right">
    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addToCartModal<?php echo e($service->id); ?>">
        Add to cart
    </button>
</div>
<div class="modal fade" id="addToCartModal<?php echo e($service->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="addToCartModal<?php echo e($service->id); ?>Label" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addToCartModal<?php echo e($service->id); ?>Label">Select body type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    
                    <div class="p-2">
                        <a href="<?php echo e(url('add-to-cart/' . $service->id . '/' . $service->id)); ?>"
                            class="btn btn-secondary">
                            <?php echo e($service->name); ?>

                        </a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/livewire/sale-terminal/add-to-cart-modal.blade.php ENDPATH**/ ?>