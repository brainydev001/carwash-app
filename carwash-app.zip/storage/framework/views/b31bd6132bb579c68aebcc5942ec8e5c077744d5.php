

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('messages.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row container-fluid">
        <div class="col-md-8">
            <div class="mt-3 mb-3">
                <a href="<?php echo e(url('dashboard')); ?>" class="">
                    Dashboard
                </a>
            </div>
            
            <div class="form-group p-2">
                <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Search services">
            </div>
            
            <div class="row">
                
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 p-3">
                        <div class="card">
                            <h4 class="text-white p-2">Service Name</h4>
                            <div class="card-header">
                                <?php echo e($service->name); ?>

                            </div>
                            <div class="card-footer">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sale-terminal.add-to-cart-modal', ['service' => $service])->html();
} elseif ($_instance->childHasBeenRendered($service->id)) {
    $componentId = $_instance->getRenderedChildComponentId($service->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($service->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($service->id);
} else {
    $response = \Livewire\Livewire::mount('sale-terminal.add-to-cart-modal', ['service' => $service]);
    $html = $response->html();
    $_instance->logRenderedChild($service->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        </div>
                    </div>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-4">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/sale_terminal/index.blade.php ENDPATH**/ ?>