
<div class="modal fade" id="craeteStaffModal" tabindex="-1" role="dialog" aria-labelledby="craeteStaffModal"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="craeteStaffModal">Create Staff Member</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff.create-staff')->html();
} elseif ($_instance->childHasBeenRendered('8mIlrK3')) {
    $componentId = $_instance->getRenderedChildComponentId('8mIlrK3');
    $componentTag = $_instance->getRenderedChildComponentTagName('8mIlrK3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8mIlrK3');
} else {
    $response = \Livewire\Livewire::mount('staff.create-staff');
    $html = $response->html();
    $_instance->logRenderedChild('8mIlrK3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="craeteStaffForm">Create Staff Member</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/staff/modals.blade.php ENDPATH**/ ?>