<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(auth()->guard()->check()): ?>
        <div class="mt-3 mb-3">
            <div><?php echo e(auth()->user()->name); ?></div>
            <div><?php echo e('@'.auth()->user()->username); ?></div>
            <div><?php echo e(auth()->user()->email); ?></div>
            <div><?php echo e(auth()->user()->phone_number); ?></div>
            
            <div class="mt-1">
                <a href="<?php echo e(url('logout')); ?>">
                    Logout
                </a>
            </div>
        </div>    
    <?php endif; ?>
    
    <div class="card p-4 mt-3">
        <h3 class="text-center m-auto col-md-6">
            Welcome to minat car wash system
        </h3>
        <div class="mt-3 mb-3 text-center">
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary m-2">
                    Login
                </a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary m-2">
                    Register
                </a>
            <?php else: ?>
                <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-success m-2">
                    Dashboard
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/welcome.blade.php ENDPATH**/ ?>