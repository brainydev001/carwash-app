

<?php $__env->startSection('page'); ?>


<div class="container-fluid">
    
    <a href="<?php echo e(url('sale-terminal')); ?>">
        <button class="btn btn-sm btn-primary mr-2">
            Add Booking 
        </button>
    </a>
</div>



<?php echo $__env->make('customers\inc\data_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('customers\modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'Customers & Bookings'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/customers/index.blade.php ENDPATH**/ ?>