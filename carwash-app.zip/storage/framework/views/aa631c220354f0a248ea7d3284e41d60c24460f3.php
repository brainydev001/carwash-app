
<div class="modal fade" id="createRoleModal" tabindex="-1" role="dialog" aria-labelledby="createRoleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createRoleModalLabel">Create role</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('access-control.create-role')->html();
} elseif ($_instance->childHasBeenRendered('dQxdZdH')) {
    $componentId = $_instance->getRenderedChildComponentId('dQxdZdH');
    $componentTag = $_instance->getRenderedChildComponentTagName('dQxdZdH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dQxdZdH');
} else {
    $response = \Livewire\Livewire::mount('access-control.create-role');
    $html = $response->html();
    $_instance->logRenderedChild('dQxdZdH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="createRoleForm">Create role</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="craetePermissionModal" tabindex="-1" role="dialog" aria-labelledby="craetePermissionModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="craetePermissionModalLabel">Create permission</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('access-control.create-permission')->html();
} elseif ($_instance->childHasBeenRendered('IVPMWue')) {
    $componentId = $_instance->getRenderedChildComponentId('IVPMWue');
    $componentTag = $_instance->getRenderedChildComponentTagName('IVPMWue');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IVPMWue');
} else {
    $response = \Livewire\Livewire::mount('access-control.create-permission');
    $html = $response->html();
    $_instance->logRenderedChild('IVPMWue', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="createPermissionForm">Create permission</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/access_control/modals.blade.php ENDPATH**/ ?>