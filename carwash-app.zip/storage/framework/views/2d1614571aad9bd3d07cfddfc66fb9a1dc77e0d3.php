<div class="container-fluid m-4">
    
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row my-4">
                    <!-- Small table -->
                    <div class="col-md-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <?php if(count($customers) > 0): ?>
                                <!-- table -->
                                <table class="table datatables" id="customersDataTable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone Number</th>
                                            <th>Plate Number</th>
                                            <th>Served_by</th>
                                            <th>Time</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($customer->name); ?></td>
                                            <td><?php echo e($customer->email); ?></td>
                                            <td><?php echo e($customer->phone_number); ?></td>
                                            <td><?php echo e($customer->plate_number); ?></td>
                                            <td>Staff Ngugi</td>
                                            <td>30 hrs ago</td>
                                            <td>
                                                <a href="<?php echo e(url('customer/bookings')); ?>">
                                                    <button type="button" class="btn btn-success p-2">View
                                                        <span class="fe fe-chevron-right fe-16 ml-2"></span>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                <div class="alert alert-warning">
                                    No Customer Bookings Available.
                                    <small>Click on the toolbar to perform any action</small>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div> <!-- simple table -->
                </div> <!-- end section -->
            </div> <!-- .col-12 -->
        </div> <!-- .row -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/customers\inc\data_table.blade.php ENDPATH**/ ?>