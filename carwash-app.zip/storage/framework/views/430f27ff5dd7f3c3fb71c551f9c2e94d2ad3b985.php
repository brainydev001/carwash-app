

<?php $__env->startSection('page'); ?>


<div class="container-fluid">
     
     <a href="<?php echo e(url('invoices/manager')); ?>" class="btn btn-sm btn-primary mr-2">
        Invoices
    </a>
    
    <a href="<?php echo e(url('recieps/manager')); ?>" class="btn btn-sm btn-primary mr-2">
        Reciepts
    </a>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'Documents'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/documents/index.blade.php ENDPATH**/ ?>