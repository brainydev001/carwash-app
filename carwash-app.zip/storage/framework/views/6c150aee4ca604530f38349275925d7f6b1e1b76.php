

<?php $__env->startSection('page'); ?>


<div class="container-fluid">
    
    <button class="btn btn-sm btn-primary mr-2" data-toggle="modal" data-target="#createRoleModal">
        Create role
    </button>
    
    <button class="btn btn-sm btn-primary mr-2" data-toggle="modal" data-target="#craetePermissionModal">
        Create permission
    </button>
</div>



<?php echo $__env->make('access_control.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'Access control'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/access_control/index.blade.php ENDPATH**/ ?>