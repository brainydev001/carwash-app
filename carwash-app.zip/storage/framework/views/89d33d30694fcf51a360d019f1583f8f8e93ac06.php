

<?php $__env->startSection('page'); ?>

<?php echo $__env->make('staff.inc.staff-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',[
'title' => 'All Staff Memmber',
'breadcrumbs' => [
'Staff manager' => url('staff/manager')
]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/staff/all-staff.blade.php ENDPATH**/ ?>