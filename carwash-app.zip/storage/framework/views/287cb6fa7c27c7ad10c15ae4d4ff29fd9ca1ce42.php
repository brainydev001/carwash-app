
<div class="modal fade" id="craeteExpenseModal" tabindex="-1" role="dialog" aria-labelledby="craeteExpenseModal"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="craeteExpenseModal">Create Expense</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expenses.create-expense')->html();
} elseif ($_instance->childHasBeenRendered('eqSGMzo')) {
    $componentId = $_instance->getRenderedChildComponentId('eqSGMzo');
    $componentTag = $_instance->getRenderedChildComponentTagName('eqSGMzo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eqSGMzo');
} else {
    $response = \Livewire\Livewire::mount('expenses.create-expense');
    $html = $response->html();
    $_instance->logRenderedChild('eqSGMzo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="craeteExpenseForm">Create New Expense</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/expenses/modals.blade.php ENDPATH**/ ?>