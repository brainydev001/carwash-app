
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-body">
                            <?php if(count($services) > 0): ?>
                                <!-- table -->
                                <table class="table datatables" id="servicesDataTable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Description</th>
                                            <th class="text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($key + 1); ?>

                                                </td>
                                                <td><?php echo e($service->name); ?></td>
                                                <td>
                                                    <?php echo e($service->price); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($service->description); ?>

                                                </td>
                                                <td class="text-right">
                                                    <button class="btn btn-sm dropdown-toggle more-horizontal" type="button"
                                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <span class="text-muted sr-only">Action</span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(url('service/'.$service->id)); ?>">View</a>
                                                        
                                                    </div>
                                                </td>
                                            </tr>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    No services to show
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div> <!-- simple table -->
            </div> <!-- end section -->
        </div> <!-- .col-12 -->
    </div> <!-- .row -->
</div>
<?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/services/inc/services-table.blade.php ENDPATH**/ ?>