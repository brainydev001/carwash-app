
<div class="modal fade" id="craeteRecieptModal" tabindex="-1" role="dialog" aria-labelledby="craeteRecieptModal"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="craeteRecieptForm">Create Reciept</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reciepts.create-reciepts')->html();
} elseif ($_instance->childHasBeenRendered('TmvK61h')) {
    $componentId = $_instance->getRenderedChildComponentId('TmvK61h');
    $componentTag = $_instance->getRenderedChildComponentTagName('TmvK61h');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TmvK61h');
} else {
    $response = \Livewire\Livewire::mount('reciepts.create-reciepts');
    $html = $response->html();
    $_instance->logRenderedChild('TmvK61h', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="craeteExpenseForm">Complete payment</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/documents/modals.blade.php ENDPATH**/ ?>