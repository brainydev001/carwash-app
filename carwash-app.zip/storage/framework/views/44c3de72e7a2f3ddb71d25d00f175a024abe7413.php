


<?php $__env->startSection('appcss'); ?>
<?php echo \Livewire\Livewire::styles(); ?>


<link rel="stylesheet" href="<?php echo e(asset('admin/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation.top-nav')->html();
} elseif ($_instance->childHasBeenRendered('Mt7YRjY')) {
    $componentId = $_instance->getRenderedChildComponentId('Mt7YRjY');
    $componentTag = $_instance->getRenderedChildComponentTagName('Mt7YRjY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Mt7YRjY');
} else {
    $response = \Livewire\Livewire::mount('navigation.top-nav');
    $html = $response->html();
    $_instance->logRenderedChild('Mt7YRjY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation.side-nav')->html();
} elseif ($_instance->childHasBeenRendered('JusXvE5')) {
    $componentId = $_instance->getRenderedChildComponentId('JusXvE5');
    $componentTag = $_instance->getRenderedChildComponentTagName('JusXvE5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JusXvE5');
} else {
    $response = \Livewire\Livewire::mount('navigation.side-nav');
    $html = $response->html();
    $_instance->logRenderedChild('JusXvE5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<main role="main" class="main-content">
    
    <?php echo $__env->make('messages.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <div class="container-fluid mb-3">
        <div class="d-flex justify-content-between align-items-center">
            
            <div>
                <h4 class="m-0">
                    <?php echo e($title ?? '-add page title-'); ?>

                </h4>
            </div>
            
            <div>
                <?php if(isset($breadcrumbs)): ?>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($url); ?>">
                            <?php echo e($name); ?>

                        </a>
                        /
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php echo e($title ?? '-add page title-'); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="container-fluid">
        
        <?php echo $__env->yieldContent('page'); ?>
    </div>
</main>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('appjs'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>


<script src='<?php echo e(asset('admin/js/jquery.dataTables.min.js')); ?>'></script>
<script src='<?php echo e(asset('admin/js/dataTables.bootstrap4.min.js')); ?>'></script>

<script src="<?php echo e(asset('admin/custom/js/tables.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/layouts/admin.blade.php ENDPATH**/ ?>