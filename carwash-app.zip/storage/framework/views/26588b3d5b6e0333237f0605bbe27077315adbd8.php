

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('messages.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('checkout',['price_id' => $price->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row mt-3 mb-3 container-fluid">
            <div class="col-md-8 p-2 ">

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sale-terminal.checkout-form')->html();
} elseif ($_instance->childHasBeenRendered('n67suGP')) {
    $componentId = $_instance->getRenderedChildComponentId('n67suGP');
    $componentTag = $_instance->getRenderedChildComponentTagName('n67suGP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n67suGP');
} else {
    $response = \Livewire\Livewire::mount('sale-terminal.checkout-form');
    $html = $response->html();
    $_instance->logRenderedChild('n67suGP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
            <div class="col-md-4 p-2 mt-4">
                <div class="card">
                    <div class="card-body">
                        <h4>Service</h4>
                        <p>
                            <?php echo e($service->name); ?>

                        </p>

                        <h4>Body type</h4>
                        <p>
                            <?php echo e($body_type->name); ?>

                        </p>

                        <h5 class="text-right">
                            <span>Total: Ksh</span>
                            <?php echo e(number_format($price->price)); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="float-right m-3">
            <button class="btn btn-primary">
                Checkout
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/sale_terminal/checkout.blade.php ENDPATH**/ ?>