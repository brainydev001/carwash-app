

<?php $__env->startSection('page'); ?>


<div class="container-fluid">
     
     <a href="<?php echo e(url('all-staff')); ?>" class="btn btn-sm btn-primary mr-2">
        All Staff
    </a>
    
    <button class="btn btn-sm btn-primary mr-2" data-toggle="modal" data-target="#craeteStaffModal">
        Create Staff Member
    </button>
</div>


<?php echo $__env->make('staff.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',['title' => 'Staff'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/staff/index.blade.php ENDPATH**/ ?>