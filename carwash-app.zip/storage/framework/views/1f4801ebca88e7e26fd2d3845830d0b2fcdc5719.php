
<div class="modal fade" id="craeteServiceModal" tabindex="-1" role="dialog" aria-labelledby="craeteServiceModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="craeteServiceModalLabel">Create service</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('services.create-service')->html();
} elseif ($_instance->childHasBeenRendered('54RblGU')) {
    $componentId = $_instance->getRenderedChildComponentId('54RblGU');
    $componentTag = $_instance->getRenderedChildComponentTagName('54RblGU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('54RblGU');
} else {
    $response = \Livewire\Livewire::mount('services.create-service');
    $html = $response->html();
    $_instance->logRenderedChild('54RblGU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="createServiceForm">Create service</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="craeteBodyTypeModal" tabindex="-1" role="dialog" aria-labelledby="craeteBodyTypeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="craeteBodyTypeModalLabel">Create body type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('services.create-body-type')->html();
} elseif ($_instance->childHasBeenRendered('6DEonNE')) {
    $componentId = $_instance->getRenderedChildComponentId('6DEonNE');
    $componentTag = $_instance->getRenderedChildComponentTagName('6DEonNE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6DEonNE');
} else {
    $response = \Livewire\Livewire::mount('services.create-body-type');
    $html = $response->html();
    $_instance->logRenderedChild('6DEonNE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="createBodyTypeForm">Create body type</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addBodyTypeModal" tabindex="-1" role="dialog" aria-labelledby="addBodyTypeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBodyTypeModalLabel">Add body type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php if(isset($service)): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('services.add-body-type',['service' => $service])->html();
} elseif ($_instance->childHasBeenRendered('V2jqg8P')) {
    $componentId = $_instance->getRenderedChildComponentId('V2jqg8P');
    $componentTag = $_instance->getRenderedChildComponentTagName('V2jqg8P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('V2jqg8P');
} else {
    $response = \Livewire\Livewire::mount('services.add-body-type',['service' => $service]);
    $html = $response->html();
    $_instance->logRenderedChild('V2jqg8P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>    
                <?php endif; ?>
                
                
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" form="addBodyTypeForm">Add body type</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\carwash-app\resources\views/services/modals.blade.php ENDPATH**/ ?>