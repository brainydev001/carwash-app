@extends('layouts.error',[
    'statusCode' => 410,
    'message' => 'the resource requested is outdated, unusable or has been permanently deleted'
])

