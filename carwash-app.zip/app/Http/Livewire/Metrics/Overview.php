<?php

namespace App\Http\Livewire\Metrics;

use Livewire\Component;

class Overview extends Component
{
    public function render()
    {
        return view('livewire.metrics.overview');
    }
}
